'use client';

import { useState } from 'react';
import Link from 'next/link';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { sendPasswordResetEmail } from 'firebase/auth';
import { firebaseAuth } from '@/lib/firebase';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { ArrowLeft } from 'lucide-react';

const formSchema = z.object({
  email: z.string().email({ message: 'Please enter a valid email address.' }),
});

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [userEmail, setUserEmail] = useState('');

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { email: '' },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    try {
      await sendPasswordResetEmail(firebaseAuth, values.email);
      setUserEmail(values.email);
      setIsSubmitted(true);
    } catch (err: any) {
      // Don't reveal whether email exists — always show success
      setUserEmail(values.email);
      setIsSubmitted(true);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <>
      <Link href="/login" className="flex items-center text-muted-foreground mb-4 hover:text-foreground">
        <ArrowLeft size={16} className="mr-1" /> Back to sign in
      </Link>

      {isSubmitted ? (
        <div>
          <h1 className="text-3xl font-bold mb-2">Check your email</h1>
          <p className="text-muted-foreground mb-6">
            We&apos;ve sent a password reset link to <span className="font-medium">{userEmail}</span>
          </p>
          <p className="mb-8">Please check your email and follow the instructions to reset your password.</p>
          <Link href="/login">
            <Button className="w-full h-12 bg-black hover:bg-foreground text-background">
              Back to Sign in
            </Button>
          </Link>
        </div>
      ) : (
        <div>
          <h1 className="text-3xl font-bold mb-2">Forgot password?</h1>
          <p className="text-muted-foreground mb-8">No worries, we&apos;ll send you reset instructions.</p>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="Your email address" type="email" {...field} className="h-12" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full h-12 bg-black hover:bg-foreground text-background"
                disabled={isLoading}
              >
                {isLoading ? 'Sending...' : 'Reset password'}
              </Button>
            </form>
          </Form>
        </div>
      )}
    </>
  );
}
