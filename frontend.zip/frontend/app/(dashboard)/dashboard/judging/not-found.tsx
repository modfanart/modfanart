import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { FileQuestion, PlusCircle } from 'lucide-react';

export default function LinkNotFound() {
  return (
    <div className="flex flex-col items-center justify-center h-full p-6">
      <div className="flex items-center justify-center w-12 h-12 rounded-full bg-warning-subtle mb-4">
        <FileQuestion className="h-6 w-6 text-warning-strong" />
      </div>
      <h2 className="text-2xl font-bold mb-4">Link Not Found</h2>
      <p className="text-muted-foreground mb-6 text-center max-w-md">
        This voting link doesn't exist or has been removed.
      </p>
      <div className="flex flex-col sm:flex-row gap-4">
        <Link href="/dashboard/judging">
          <Button variant="outline">Return</Button>
        </Link>
      </div>
    </div>
  );
}
