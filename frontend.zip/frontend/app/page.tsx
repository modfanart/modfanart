'use client';

import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { LayoutWrapper } from '@/components/layouts/layout-wrapper';
// SafeImage: renders a real Next/Image when src exists, otherwise a placeholder div
import { ImageProps } from 'next/image';
// import { contests } from "@/public/testContests.tsx";

//ICONS
import arrowImg from '@/assets/images/backgrounds/back_1.png';
import bckground from '@/assets/images/backgrounds/back_2.png';
import award1 from '@/assets/images/icons/award1.png';
import palette from '@/assets/images/icons/paint-palette.png';
import info from '@/assets/images/icons/info.png';
import idea from '@/assets/images/icons/idea.png';
import award2 from '@/assets/images/icons/award2.png';
import checklist1 from '@/assets/images/icons/checklist1.png';
import question1 from '@/assets/images/icons/question1.png';
import eye1 from '@/assets/images/icons/eye1.png';
import { useRouter } from 'next/navigation';
import Link from 'next/dist/client/link';

const contests = [
  {
    id: 1,
    contestName: "The Librarians",
    brandName: "Electric Entertainment",
    image: "/contests/librarianCard.jpg",
    link: "/contest/contest_the_librarians_2026",
  },
  // {
  //   id: 2,
  //   contestName: "Tech Creator Challenge",
  //   brandName: "Apple",
  //   image: "/contests/apple-tech.jpg",
  // },
  // {
  //   id: 3,
  //   contestName: "Gaming Gear Sweepstakes",
  //   brandName: "Razer",
  //   image: "/contests/razer-gaming.jpg",
  // },
  // {
  //   id: 4,
  //   contestName: "Travel Adventure Contest",
  //   brandName: "GoPro",
  //   image: "/contests/gopro-travel.jpg",
  // },
  // {
  //   id: 5,
  //   contestName: "Fitness Transformation Challenge",
  //   brandName: "Under Armour",
  //   image: "/contests/underarmour-fitness.jpg",
  // },
  // {
  //   id: 6,
  //   contestName: "Home Makeover Giveaway",
  //   brandName: "IKEA",
  //   image: "/contests/ikea-home.jpg",
  // },
];

type SafeImageProps = {
  src?: string | null;
  alt?: string;
  fill?: boolean;
  className?: string;
} & Omit<ImageProps, 'src' | 'alt' | 'fill'>;

function SafeImage({ src, alt = '', fill = false, className = '', ...rest }: SafeImageProps) {
  const isEmpty = !src || String(src).trim() === '';

  if (isEmpty) {
    return (
      <div
        aria-label={alt || 'image placeholder'}
        className={`relative w-full h-full ${className} bg-muted animate-pulse`}
      />
    );
  }

  return <Image src={src} alt={alt} fill={fill} className={className} {...rest} />;
}

export default function HomePage() {
  const router = useRouter();
  const images = [
    'https://res.cloudinary.com/dbsdj2f2l/image/upload/f_auto,q_auto/2331c71fb8e497567176ade34ff7b72c0b0d3594_f2s2gp', // top-left
    'https://res.cloudinary.com/dbsdj2f2l/image/upload/f_auto,q_auto/ae950b44c9b4311155d3820c4406ac501b12527a_ig1tdr', // top-right
    'https://res.cloudinary.com/dbsdj2f2l/image/upload/f_auto,q_auto/b2ba556c28829d4a1b763b4887112c3a2c18fa16_n0lii0', // bottom-left
    'https://res.cloudinary.com/dbsdj2f2l/image/upload/f_auto,q_auto/0672b8107e6a5934d017d3d77f0e0289150a6fc1_xxbpsq', // bottom-right
  ];
  return (
    <main className="w-full overflow-x-hidden">
      {/* ================= HERO ================= */}
      <section className="relative w-full h-[80vh] min-h-[420px] overflow-hidden">
        {/* BG */}
        <SafeImage
          src="https://res.cloudinary.com/dbsdj2f2l/image/upload/f_auto,q_auto/homepage-1_m1qic6"
          alt=""
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/60" />

        {/* HEADLINE */}
        <div className="absolute top-24 left-1/2 -translate-x-1/2 text-center text-white max-w-3xl px-4 z-20 mb-10">
          <h1 className="text-5xl font-extrabold leading-tight">
            TURN <span className="text-primary">FAN ART</span> INTO
            <br />
            OFFICIAL OPPORTUNITIES
          </h1>
          <p className="mt-4 text-sm text-gray-300">
            MOD Fan Official is a structured fan licensing platform that connects artists and brands
            through brand-approved submissions, official reviews, and licensed merchandise drops.
            Every design enters through a structured review and licensing process.
          </p>
          <p className="mt-2 text-sm text-gray-300">
            Brand approval ensures each release meets official guidelines and quality standards.
            Every licensed drop is backed directly by the IP holder.
          </p>
        </div>
      </section>

      {/* BRIDGING CARDS */}
      <section className="relative z-20 flex flex-col items-center gap-6 px-4 bg-[#E9E3F5]">
        {/* Cards row */}
        <div className="flex justify-center gap-6 flex-wrap -mt-36">
          {[
            {
              src: 'https://res.cloudinary.com/dbsdj2f2l/image/upload/f_auto,q_auto/homepage-2_buiw8t',
              label: 'For Artists',
              href: '/for-artists',
            },
            {
              src: 'https://res.cloudinary.com/dbsdj2f2l/image/upload/f_auto,q_auto/homepage-3_jarrp0',
              label: 'For Brands',
              href: '/for-brands',
            },
          ].map((card, i) => (
            <div
              key={i}
              className="relative w-[300px] h-[300px] rounded-2xl overflow-hidden shadow-2xl group transition-all transform hover:scale-105"
            >
              <SafeImage src={card.src} alt={card.label} fill className="object-cover" />
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
                <Button
                  onClick={() => router.push(card.href)}
                  className="rounded-full bg-background text-foreground text-xs px-5 py-2 transition-all transform group-hover:scale-105"
                >
                  ✔ {card.label}
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* CTA below cards, in normal flow */}
        <Button
          onClick={() =>
            document.getElementById('featured')?.scrollIntoView({ behavior: 'smooth' })
          }
          className="rounded-full bg-black text-white text-sm px-6 py-2 hover:bg-background hover:text-foreground transition-colors duration-200"
        >
          <img src={eye1.src} alt="Info" className="w-4 h-4" /> View Active Contests
        </Button>
      </section>

      {/* ================= HOW IT WORKS ================= */}
      <section className="bg-gradient-to-b from-[#E9E3F5] to-white py-20 px-6 text-center animate-fade-in-up">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-semibold">
            HOW <span className="text-primary">MOD</span> WORKS
          </h2>

          <p className="mt-3 text-sm text-muted-foreground max-w-xl mx-auto">
            Fan art has always been part of culture. What's been missing is a clear, legal way for
            it to become official. MOD creates that path.
          </p>

          <div className="mt-12 flex flex-col md:flex-row items-stretch justify-center md:gap-0 gap-4">
            {[
              'Artists submit fan creations as part of real brand campaigns.',
              "Each submission is screened using MOD's AI-powered review system and checked against brand guidelines, helping streamline evaluation while preserving full brand approval control.",
              'Brands review what fits and approve what they want to license.',
            ].map((text, i) => (
              <div key={i} className="flex items-center">
                <div
                  className={`bg-[#DCD3F2] rounded-xl px-5 py-4 text-xs shadow-sm hover:shadow-lg transition-shadow duration-200 flex items-center justify-center text-center h-full ${
                    i === 1 ? 'w-[320px]' : 'w-[220px]'
                  }`}
                >
                  {text}
                </div>

                {i < 2 && (
                  <div className="hidden md:block w-8 flex-shrink-0">
                    <img src={arrowImg.src} alt="arrow" className="w-8 h-7 object-contain" />
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-8">
            <div className="bg-primary text-primary-foreground text-xs px-6 py-3 rounded-full inline-block">
              ✔ Approved designs move forward as officially licensed merchandise.
            </div>

            <p className="mt-3 text-sm text-muted-foreground max-w-xl mx-auto">
              No guessing. No copyright gray areas. <br /> Just a process that respects both
              creativity and IP.
            </p>
          </div>
        </div>
      </section>

      {/* ================= BUILT FOR ================= */}
      <section className="px-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Brands */}
          <div className="bg-black text-white rounded-3xl grid md:grid-cols-2 items-center overflow-hidden">
            <div className="p-10">
              <div className="flex items-center gap-3 mb-4">
                <span className="w-10 h-10 rounded-full bg-background flex items-center justify-center mb-4">
                  <img src={award1.src} alt="Award 1" className="w-6 h-6" />
                </span>

                <h3 className="text-2xl font-semibold -translate-y-2">Built for Brands</h3>
              </div>
              <p className="mt-4 text-muted-foreground text-sm">
                Fans already create artwork inspired by your IP. That doesn't stop whether you
                engage or not. MOD gives brands a way to participate without losing control.
              </p>
              <p className="mt-2 text-muted-foreground text-sm">
                You set the rules. <br />
                You review submissions. <br />
                You decide what becomes official. The result is safer fan engagement, licensed fan
                merchandise, and campaigns that feel intentional instead of risky.
              </p>
              <p className="mt-2 text-muted-foreground text-sm">
                For brands that want fan engagement without putting their IP at risk.
              </p>
            </div>
            <div className="relative h-[450px] rounded-2xl overflow-hidden">
              <SafeImage
                src="https://res.cloudinary.com/dbsdj2f2l/image/upload/f_auto,q_auto/homepage-4_zqgxz6"
                alt="Brand art"
                fill
                className="object-cover"
              />
            </div>
          </div>

          {/* Artists */}
          <div className="bg-black text-white rounded-3xl grid md:grid-cols-2 items-center">
            <div className="relative h-[450px] rounded-2xl overflow-hidden">
              <SafeImage
                src="https://res.cloudinary.com/dbsdj2f2l/image/upload/f_auto,q_auto/homepage-5_lzkqew"
                alt="Artist art"
                fill
                className="object-cover"
              />
            </div>
            <div className="p-10">
              <div className="flex items-center gap-3 mb-4">
                <span className="w-10 h-10 rounded-full bg-background flex items-center justify-center mb-4">
                  <img src={palette.src} alt="Paint Palette" className="w-6 h-6" />
                </span>

                <h3 className="text-2xl font-semibold -translate-y-2">Built for Artists</h3>
              </div>
              <p className="mt-4 text-muted-foreground text-sm">
                Most fan art lives in a legal gray zone.
                <br /> That makes it hard to share, harder to monetize, and nearly impossible to
                build a future around. MOD gives artists a real way in.
              </p>
              <p className="mt-2 text-muted-foreground text-sm">
                You submit work tied to official fan art contests.
                <br /> Your designs are reviewed instead of ignored.
                <br /> If approved, your work becomes licensed merchandise and earns royalties.
              </p>
              <p className="mt-2 text-muted-foreground text-sm">
                When your design is selected, it becomes officially licensed merchandise backed by
                the brand, with real recognition and royalties attached.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ================= FEATURED ================= */}
      <section
        id="featured"
        className="bg-background py-24 px-6 text-center"
        aria-label="Featured campaigns"
      >
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-semibold">FEATURED CAMPAIGNS</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            MOD runs official fan art licensing campaigns with brands across entertainment, gaming,
            media, and fandom culture.
          </p>
          <p className="mt-2 text-sm text-muted-foreground">Each campaign includes:</p>
          <div className="mt-4 flex flex-col items-center gap-3">
            <div className="flex gap-3">
              <div className="bg-muted text-foreground font-semibold text-xs px-6 py-3 rounded-full">
                ✔ Clear brand guidelines
              </div>
              <div className="bg-muted text-foreground font-semibold text-xs px-6 py-3 rounded-full">
                ✔ Defined Submission Windows
              </div>
            </div>
            <div className="flex gap-3">
              <div className="bg-muted text-foreground font-semibold text-xs px-6 py-3 rounded-full">
                ✔ Brand-led Review and Approval
              </div>
              <div className="bg-muted text-foreground font-semibold text-xs px-6 py-3 rounded-full">
                ✔ Licensed Merchandise Outcomes
              </div>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">
              These aren’t speculative uploads. <br /> They’re structured opportunities backed by
              real IP holders.
            </p>
          </div>
          <div className="mt-12">
            <div className="flex gap-6 overflow-x-auto pb-4 scrollbar-thin">
              {contests.map((contest) => (
                <div
                  key={contest.id}
                  className="
                    flex-shrink-0
                    w-[280px]
                    md:w-[calc((100%-3rem)/3)]
                    bg-muted
                    rounded-xl
                    overflow-hidden
                    transform
                    hover:scale-105
                    transition-transform
                    duration-300
                  "
                >
                  <div className="relative h-48">
                    <SafeImage
                      src={contest.image}
                      alt={contest.contestName}
                      fill
                      className="object-cover"
                    />
                  </div>

                  <div className="p-4 text-left">
                    <p className="text-xs text-muted-foreground mb-1">
                      {contest.brandName}
                    </p>

                    <h4 className="font-medium">
                      {contest.contestName}
                    </h4>

                    <Link href={contest.link}>
                      <Button className="mt-3 text-xs rounded-full">
                        View and Enter
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ================= WHY ================= */}
      <section className="py-4 px-6" aria-label="Why MOD exists">
        <div className="max-w-5xl mx-auto">
          {/* Title */}
          <h2 className="text-4xl font-black text-center tracking-wide mb-12">
            WHY <span className="text-primary">MOD</span> EXISTS
          </h2>

          {/* Two-column body */}
          <div className="flex flex-col md:flex-row gap-10 items-start">
            {/* Left: bullet points */}
            <div className="flex-1 space-y-7">
              {[
                {
                  icon: <img src={idea.src} alt="icon" className="w-5 h-5 object-contain" />,
                  color: 'bg-primary-subtle',
                  text: "Fan creativity has always driven fandom forward. Licensing systems just weren't built to include it.",
                },
                {
                  icon: <img src={award2.src} alt="icon" className="w-5 h-5 object-contain" />,
                  color: 'bg-primary-subtle',
                  text: 'We believe fan art deserves structure, not chaos. We believe brands should be able to collaborate without risk.',
                },
                {
                  icon: <img src={checklist1.src} alt="icon" className="w-5 h-5 object-contain" />,
                  color: 'bg-primary-subtle',
                  text: 'And we believe official pathways create better outcomes than gray areas ever could.',
                },
                {
                  icon: <img src={question1.src} alt="icon" className="w-5 h-5 object-contain" />,
                  color: 'bg-primary-subtle',
                  text: 'Artists were left guessing what was allowed. Brands were left choosing between enforcement or silence. MOD exists to change that.',
                },
              ].map(({ icon, color, text }, i) => (
                <div key={i} className="flex items-start gap-4">
                  <div
                    className={`${color} rounded-full w-9 h-9 flex items-center justify-center shrink-0 text-base`}
                  >
                    {icon}
                  </div>
                  <p className="text-foreground text-sm leading-relaxed">{text}</p>
                </div>
              ))}
            </div>

            {/* Right: staggered 2×2 image grid */}
            <div className="flex-1 flex gap-x-3">
              {/* Left image column — offset down */}
              <div className="flex flex-col gap-3 mt-10">
                {[images[0], images[2]].map((src, i) => (
                  <img
                    key={i}
                    src={src}
                    alt={`Fan art ${i + 1}`}
                    className="rounded-2xl w-[200px] h-[200px] object-cover"
                  />
                ))}
              </div>

              {/* Right image column — sits higher */}
              <div className="flex flex-col gap-3">
                {[images[1], images[3]].map((src, i) => (
                  <img
                    key={i}
                    src={src}
                    alt={`Fan art ${i + 2}`}
                    className="rounded-2xl w-[200px] h-[200px] object-cover"
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Button */}
          <div className="mt-12 flex justify-center">
            <Button
              onClick={() => router.push('/about')}
              className="rounded-full px-8 py-2 bg-foreground text-background text-sm flex items-center gap-2 hover:bg-foreground"
            >
              <img src={info.src} alt="Info" className="w-4 h-4" /> About Us
            </Button>
          </div>
        </div>
      </section>

      {/* ================= CTA ================= */}
      <section className="py-24 px-6">
        <div
          className="relative max-w-5xl mx-auto rounded-3xl overflow-hidden bg-cover bg-center bg-no-repeat py-20 px-10"
          style={{ backgroundImage: `url(${bckground.src})` }}
        >
          {/* overlay */}
          <div className="absolute inset-0 bg-black/60" />

          {/* content */}
          <div className="relative z-10 text-center text-white">
            <h2 className="text-4xl font-bold">
              READY TO <span className="text-primary">GET STARTED?</span>
            </h2>
            <p className="mt-4 text-gray-300 text-sm">
              Whether you're a brand looking to activate your fandom safely or an artist looking to
              monetize fan art legally, MOD Fan Official gives you a clear place to start.
            </p>

            <div className="mt-6 flex justify-center gap-3 flex-wrap">
              {['Explore campaigns', 'Submit artwork', 'Launch brand activation'].map((t, i) => (
                <div
                  key={i}
                  className="bg-background/10 px-4 py-2 rounded-full text-xs hover:bg-background/20 transition-colors"
                >
                  ✔ {t}
                </div>
              ))}
            </div>

            <p className="mt-6 text-gray-300 text-lg">
              Turn fan passion into official partnerships.
            </p>

            <div className="mt-6 flex justify-center gap-4">
              <Button
                onClick={() => router.push('/signup')}
                className="bg-primary rounded-full px-6"
              >
                Sign Up Now
              </Button>
              <Button
                onClick={() => router.push('/contact/sales')}
                variant="outline"
                className="text-foreground rounded-full px-6"
              >
                Contact Sales
              </Button>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}